#ifndef DATOS_H
#define DATOS_H

enum Turno { Manana, Tarde, Noche };

#endif
