#include <iostream>
#include <string>
using namespace std;

#include "C.h"
#include "B.h"
#include "A.h"

int main(int argc, char** argv) {
	A* insA = new A();
	B* insB = new B();
	C* insC = new C();
	insA->imprimir();
	insB->imprimir();
	insC->imprimir();
}
